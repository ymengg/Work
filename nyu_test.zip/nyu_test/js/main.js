(function(){
    var bannerSwiper = new Swiper('#banner-swiper',{
        autoplay: {
            deplay: 5000,
        },
        pagination: {
            el:'.swiper-pagination',
            type:'bullets'
        },
        observer: true
    });
})()