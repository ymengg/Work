(function($){
    var bannerSwiper = new Swiper('#banner-swiper',{
        autoplay: {
            deplay: 5000,
        },
        speed: 2000,
        pagination: {
            el:'.swiper-pagination',
            type:'bullets'
        },
        observer: true
    });
    var eventSwiper = new Swiper('#event-list',{
        autoplay: {
            deplay: 5000,
        },
        slidesPerView: 3,
        loop: true,
        speed: 2000,
        observer: true,
        centeredSlides: true
    });
    $('#open-menu').on('click', function(e){
        e.stopPropagation();
        e.preventDefault();
        $('.fa-times').removeClass('hide').addClass('show');
        $('.fa-bars').removeClass('show').addClass('hide');
        $(".mobile-menu-content").removeClass('hide').addClass('show');
    })
    $('#close-menu').on('click', function(e){
        e.stopPropagation();
        e.preventDefault();
        $('.fa-times').removeClass('show').addClass('hide');
        $('.fa-bars').removeClass('hide').addClass('show');
        $(".mobile-menu-content").removeClass('show').addClass('hide');
    })
    $("#current-m").on('click', function(){
        $(".event-list").toggleClass('off');
    })
})(jQuery)